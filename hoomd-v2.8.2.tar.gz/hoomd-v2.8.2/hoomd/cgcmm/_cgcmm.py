# This file exists to allow the hoomd module to import from the source checkout dir
# for use when building the sphinx documentation.
