---
name: Feature request
about: Suggest a new HOOMD-blue feature
title: ''
labels: 'enhancement'
assignees: ''

---

## Description

<!-- What new capability would you like in HOOMD-blue? -->

## Proposed solution

<!-- How should this capability be implemented? -->
<!-- What might the user API look like? -->

## Additional context

<!-- What additional information is helpful to understand this request? -->

## Developer

<!-- Are you able to implement this feature for the benefit of the HOOMD-blue user community? -->
